# Linkedin_Scrapper
A way to scrappe data in linkedin

# Installation
```
pip install linkedin_scraper
```

# Products
Person scraper

Company scraper , coming soon...

# How to use it?
It's very simple, what you need are just, you're `linkedin email account` and your `password`.
Like a lot of person can have the same name, you need to know the company where he work, it'll easier 
to find the right person like that.

### Usage example
```
from linkedin_scraper import Account, Person
```


